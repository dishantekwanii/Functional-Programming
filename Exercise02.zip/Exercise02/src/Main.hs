module Main where

import Ex02

main = putStrLn declaration
