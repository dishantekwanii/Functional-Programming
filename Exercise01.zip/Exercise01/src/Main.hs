module Main where

import Ex01

main = putStrLn "Hello World :-)"
