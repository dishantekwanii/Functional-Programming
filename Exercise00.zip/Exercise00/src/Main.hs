module Main where

import Ex00

main
  = putStrLn $ unlines
      [ declaration
      , hello
      ]
